# OpenCode Console (Android)

Агент-чат с реальными инструментами: файлы на телефоне, shell, поиск и загрузка страниц из интернета, HTTP-запросы.
UI — WebView (app/src/main/assets/index.html), инструменты — Kotlin (Bridge.kt).

## Сборка APK
1. Залей папку в GitHub-репозиторий, вкладка Actions -> Build APK -> скачай артефакт.
   Или локально: Android Studio (Open) -> Build -> Build APK, либо `gradle assembleDebug`.
2. APK: app/build/outputs/apk/debug/app-debug.apk

## Первый запуск
Выдай доступ ко всем файлам, затем в Настройках (иконка меню) укажи Base URL, API-ключ и модель
(любой OpenAI-совместимый API с tool calling).
