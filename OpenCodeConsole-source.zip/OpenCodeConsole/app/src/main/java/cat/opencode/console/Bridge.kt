package cat.opencode.console

import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/** Мост JS -> Android. Все инструменты агента реально работают тут. */
class Bridge(private val web: WebView) {
    private val ua = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124.0 Mobile Safari/537.36"

    @JavascriptInterface
    fun call(id: String, name: String, args: String) {
        Thread {
            val r = try { run(name, JSONObject(args)) } catch (e: Throwable) { "Ошибка: " + (e.message ?: e.toString()) }
            reply(id, r)
        }.start()
    }

    @JavascriptInterface
    fun llm(id: String, url: String, key: String, body: String) {
        Thread {
            val r = try {
                http("POST", url, mapOf("Content-Type" to "application/json", "Authorization" to "Bearer $key"), body).second
            } catch (e: Throwable) {
                JSONObject().put("error", JSONObject().put("message", e.message ?: e.toString())).toString()
            }
            reply(id, r)
        }.start()
    }

    private fun reply(id: String, r: String) {
        web.post { web.evaluateJavascript("__cb(${JSONObject.quote(id)},${JSONObject.quote(r)})", null) }
    }

    private fun abs(s: String): String { val t = s.trim(); return if (t.startsWith("/")) t else "/sdcard/Download/$t" }
    private fun f(a: JSONObject) = File(abs(a.getString("path")))

    private fun run(n: String, a: JSONObject): String = when (n) {
        "read_file" -> { val x = f(a); if (!x.isFile) throw Exception("файл не найден: ${x.path}"); x.readText().take(100_000) }
        "write_file" -> { val x = f(a); x.parentFile?.mkdirs(); x.writeText(a.getString("content")); "OK, записано ${x.length()} байт в ${x.path}" }
        "append_file" -> { val x = f(a); x.parentFile?.mkdirs(); x.appendText(a.getString("content")); "OK" }
        "delete_file" -> { val x = f(a); if (!x.exists()) throw Exception("не найдено: ${x.path}"); x.deleteRecursively(); "OK, удалено" }
        "make_dir" -> { f(a).mkdirs(); "OK" }
        "move_file" -> {
            val s = File(abs(a.getString("source"))); val d = File(abs(a.getString("destination")))
            if (!s.exists()) throw Exception("не найдено: ${s.path}")
            d.parentFile?.mkdirs()
            if (!s.renameTo(d)) { s.copyRecursively(d, true); s.deleteRecursively() }
            "OK"
        }
        "list_dir" -> {
            val x = f(a)
            val l = x.listFiles() ?: throw Exception("папка не найдена или нет доступа: ${x.path}")
            l.sortedBy { it.name }.joinToString("\n") { if (it.isDirectory) it.name + "/" else "${it.name} (${it.length()} B)" }.ifBlank { "(пусто)" }
        }
        "search_files" -> {
            val q = a.getString("query"); val o = StringBuilder()
            f(a).walkTopDown().filter { it.isFile && it.length() < 1_000_000 }.forEach { x ->
                if (o.length < 20_000) try {
                    x.readLines().forEachIndexed { i, l -> if (l.contains(q, true)) o.appendLine("${x.path}:${i + 1}: ${l.trim().take(200)}") }
                } catch (e: Exception) {}
            }
            o.toString().ifBlank { "не найдено" }
        }
        "execute_command" -> shell(a.getString("cmd"))
        "web_search" -> search(a.getString("query"))
        "web_fetch" -> text(http("GET", a.getString("url"), emptyMap(), null).second)
        "http_request" -> {
            val h = HashMap<String, String>()
            a.optJSONObject("headers")?.let { o -> o.keys().forEach { k -> h[k] = o.getString(k) } }
            val r = http(a.getString("method").uppercase(), a.getString("url"), h, a.optString("body", "").ifEmpty { null })
            "HTTP ${r.first}\n${r.second}".take(20_000)
        }
        else -> throw Exception("неизвестный инструмент: $n")
    }

    private fun http(m: String, u: String, h: Map<String, String>, body: String?): Pair<Int, String> {
        val c = URL(u).openConnection() as HttpURLConnection
        c.requestMethod = m; c.connectTimeout = 20_000; c.readTimeout = 180_000
        c.setRequestProperty("User-Agent", ua)
        h.forEach { (k, v) -> c.setRequestProperty(k, v) }
        if (body != null) { c.doOutput = true; c.outputStream.use { it.write(body.toByteArray()) } }
        val code = c.responseCode
        val s = (if (code < 400) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        return Pair(code, s)
    }

    private fun shell(cmd: String): String {
        val p = ProcessBuilder("sh", "-c", cmd).directory(File("/sdcard/Download")).redirectErrorStream(true).start()
        val out = StringBuilder()
        val t = Thread { p.inputStream.bufferedReader().forEachLine { if (out.length < 50_000) out.appendLine(it) } }
        t.start()
        val done = p.waitFor(30, TimeUnit.SECONDS)
        if (!done) p.destroy()
        t.join(1000)
        return out.toString().ifBlank { "(пусто)" } + if (done) "\n[exit ${p.exitValue()}]" else "\n[таймаут 30с]"
    }

    private fun clean(s: String) = s.replace(Regex("<[^>]+>"), "").replace("&amp;", "&").replace("&quot;", "\"")
        .replace("&#x27;", "'").replace("&lt;", "<").replace("&gt;", ">").trim()

    private fun text(h: String) = clean(
        h.replace(Regex("(?is)<(script|style|noscript)[^>]*>.*?</\\1>"), " ").replace(Regex("(?s)<[^>]+>"), " ")
    ).replace(Regex("\\s+"), " ").take(20_000)

    private fun search(q: String): String {
        val h = http("GET", "https://html.duckduckgo.com/html/?q=" + URLEncoder.encode(q, "UTF-8"), emptyMap(), null).second
        val re = Regex("""class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>[\s\S]*?class="result__snippet"[^>]*>(.*?)</a>""")
        return re.findAll(h).take(8).joinToString("\n\n") { m ->
            val u = Regex("uddg=([^&]+)").find(m.groupValues[1])?.let { URLDecoder.decode(it.groupValues[1], "UTF-8") } ?: m.groupValues[1]
            "${clean(m.groupValues[2])}\n$u\n${clean(m.groupValues[3])}"
        }.ifBlank { "ничего не найдено" }
    }
}
